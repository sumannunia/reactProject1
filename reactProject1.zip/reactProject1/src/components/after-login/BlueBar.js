import React from 'react'

export const BlueBar = () => {
    return (
        <div className="theBlueBarWithouttimer">
            <h3 className="theSelectQuiz-title">Select your Quiz</h3>
        </div>
    )
}
