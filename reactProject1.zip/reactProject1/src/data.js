export const data = [
    {
        id: 1,
        title: "hello bro"
    },
    {
        id: 2,
        title: "hello sam"
    },
    {
        id: 3,
        title: "hello ravi"
    },
    {
        id: 4,
        title: "hello Mangla"
    }
]
